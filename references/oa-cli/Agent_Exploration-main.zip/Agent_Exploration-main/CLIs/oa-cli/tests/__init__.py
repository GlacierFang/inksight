"""OA CLI tests."""
